package com.imooc.seataproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeataProductApplication {

    public static void main(String[] args) {
        SpringApplication.run(SeataProductApplication.class, args);
    }
}
